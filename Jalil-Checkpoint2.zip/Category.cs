﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLista2App
{
    class Category
    {
        /*private string categoryName;
        private List<string> categorylist = new List<string>();
        private int categoryCount;
        public string CategoryName { get; set; }

        public void AddCategory(string categoryName)
        {

        }

        public void Validate() {
           
        }
        public List<string> GetCategoryList()
        {
            return categorylist;
        }*/

    }
}
